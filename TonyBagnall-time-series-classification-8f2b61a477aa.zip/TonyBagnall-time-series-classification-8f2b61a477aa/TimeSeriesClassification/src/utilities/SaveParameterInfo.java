
package utilities;

import weka.core.Instances;

/**
 *
 * @author ajb
 */
public interface SaveParameterInfo {
    String getParameters();
    
}
