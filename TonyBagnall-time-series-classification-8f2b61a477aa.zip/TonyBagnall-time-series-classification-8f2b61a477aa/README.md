# README #

Time Series Classification code, very much in development. More info will be on www.timeseriesclassification.com. Contact Tony for more info